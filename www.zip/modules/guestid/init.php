<? defined('SYSPATH') or die('No direct script access.');


//for init


?>