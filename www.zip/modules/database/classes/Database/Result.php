<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Database_Result extends Kohana_Database_Result {}
