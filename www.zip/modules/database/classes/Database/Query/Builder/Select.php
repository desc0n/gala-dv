<?php defined('SYSPATH') OR die('No direct script access.');

class Database_Query_Builder_Select extends Kohana_Database_Query_Builder_Select {}
