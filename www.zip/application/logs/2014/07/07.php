<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-07-07 13:23:09 --- CRITICAL: ErrorException [ 8 ]: Undefined index: username ~ APPPATH\classes\Controller\Registration.php [ 112 ] in Z:\home\avz125.ru\www\application\classes\Controller\Registration.php:112
2014-07-07 13:23:09 --- DEBUG: #0 Z:\home\avz125.ru\www\application\classes\Controller\Registration.php(112): Kohana_Core::error_handler(8, 'Undefined index...', 'Z:\home\avz125....', 112, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Registration->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Registration))
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#7 {main} in Z:\home\avz125.ru\www\application\classes\Controller\Registration.php:112
2014-07-07 14:00:17 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE, expecting T_FUNCTION ~ APPPATH\classes\Controller\Registration.php [ 175 ] in :
2014-07-07 14:00:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-07-07 14:00:57 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE, expecting T_FUNCTION ~ APPPATH\classes\Controller\Registration.php [ 175 ] in :
2014-07-07 14:00:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-07-07 14:01:04 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: password ~ APPPATH\classes\Controller\Registration.php [ 151 ] in Z:\home\avz125.ru\www\application\classes\Controller\Registration.php:151
2014-07-07 14:01:04 --- DEBUG: #0 Z:\home\avz125.ru\www\application\classes\Controller\Registration.php(151): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 151, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Registration->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Registration))
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#7 {main} in Z:\home\avz125.ru\www\application\classes\Controller\Registration.php:151
2014-07-07 14:01:54 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: headers ~ APPPATH\classes\Controller\Registration.php [ 163 ] in Z:\home\avz125.ru\www\application\classes\Controller\Registration.php:163
2014-07-07 14:01:54 --- DEBUG: #0 Z:\home\avz125.ru\www\application\classes\Controller\Registration.php(163): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 163, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Registration->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Registration))
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#7 {main} in Z:\home\avz125.ru\www\application\classes\Controller\Registration.php:163
2014-07-07 14:11:20 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\Controller\Registration.php [ 107 ] in :
2014-07-07 14:11:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :