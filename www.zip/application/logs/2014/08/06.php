<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-08-06 14:48:34 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:48:34 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-08-06 14:48:44 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:48:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-08-06 14:49:31 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:49:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-08-06 14:51:22 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:51:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-08-06 14:52:08 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:52:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-08-06 14:52:38 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:52:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-08-06 14:53:01 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Comments::set_comment() ~ APPPATH\classes\Controller\Ajax.php [ 98 ] in :
2014-08-06 14:53:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :