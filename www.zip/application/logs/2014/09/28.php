<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-09-28 12:05:29 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-28 12:05:29 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:05:30 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:05:30 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:05:58 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 185 ] in :
2014-09-28 12:05:58 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:06:00 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:06:00 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:06:03 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-28 12:06:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:06:28 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 61 ] in :
2014-09-28 12:06:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:14:20 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-28 12:14:20 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:14:22 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:14:22 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:14:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:14:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:14:55 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-28 12:14:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:14:59 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 74 ] in :
2014-09-28 12:14:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:15:00 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-28 12:15:00 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:15:01 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:15:01 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:15:02 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:15:02 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:15:30 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 175 ] in :
2014-09-28 12:15:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:15:30 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 74 ] in :
2014-09-28 12:15:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:15:30 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-28 12:15:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:15:31 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-28 12:15:31 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:15:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:15:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:15:33 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:15:33 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:16:01 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-28 12:16:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:16:01 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 72 ] in :
2014-09-28 12:16:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:16:03 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-28 12:16:03 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:16:04 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:16:04 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:16:09 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-28 12:16:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:16:21 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-28 12:16:21 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-28 12:16:32 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 203 ] in :
2014-09-28 12:16:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:16:32 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 74 ] in :
2014-09-28 12:16:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-28 12:16:49 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 161 ] in :
2014-09-28 12:16:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :