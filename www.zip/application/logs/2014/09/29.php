<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-09-29 16:23:18 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-29 16:23:18 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-29 16:23:19 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-29 16:23:19 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-29 16:23:45 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 117 ] in :
2014-09-29 16:23:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-29 16:23:45 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 185 ] in :
2014-09-29 16:23:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-29 16:23:47 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-29 16:23:47 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-29 16:24:16 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 190 ] in :
2014-09-29 16:24:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :