<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-09-23 14:01:54 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:01:54 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:01:55 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:01:55 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:02:23 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:02:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:02:26 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:02:26 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:02:27 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:02:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:02:53 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 110 ] in :
2014-09-23 14:02:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:07:24 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:07:24 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:07:25 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:07:25 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:07:38 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:07:38 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:07:53 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 105 ] in :
2014-09-23 14:07:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:07:53 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:07:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:08:16 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:08:16 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:08:17 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:08:17 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:08:45 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:08:45 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:08:45 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 161 ] in :
2014-09-23 14:08:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:08:45 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 180 ] in :
2014-09-23 14:08:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:09:11 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 112 ] in :
2014-09-23 14:09:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:09:13 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:09:13 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:09:14 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:09:14 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:09:42 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 70 ] in :
2014-09-23 14:09:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:09:42 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 218 ] in :
2014-09-23 14:09:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:09:43 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:09:43 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:10:12 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:10:12 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:10:14 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:10:14 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:10:29 --- CRITICAL: ErrorException [ 2 ]: file_get_contents(http://www.sberbank.ru/primorskykrai/ru/quotes/currencies/) [function.file-get-contents]: failed to open stream: HTTP request failed!  ~ APPPATH\classes\Controller\Ajax.php [ 25 ] in :
2014-09-23 14:10:29 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'file_get_conten...', 'Z:\home\avz125....', 25, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(25): file_get_contents('http://www.sber...')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:10:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:10:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:10:43 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 78 ] in :
2014-09-23 14:10:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:10:59 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 69 ] in :
2014-09-23 14:10:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:12:30 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:12:30 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:12:31 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:12:31 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:12:59 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:12:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:12:59 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:12:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:13:02 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:13:02 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:13:29 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:13:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:13:31 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:13:31 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:13:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:13:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:14:00 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 156 ] in :
2014-09-23 14:14:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:14:00 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 183 ] in :
2014-09-23 14:14:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:14:03 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:14:03 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:14:31 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 130 ] in :
2014-09-23 14:14:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:15:47 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:15:47 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:15:48 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:15:48 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:16:16 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:16:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:16:16 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 161 ] in :
2014-09-23 14:16:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:16:19 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:16:19 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:16:47 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 175 ] in :
2014-09-23 14:16:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:17:17 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:17:17 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:17:18 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:17:18 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:17:34 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:17:34 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:17:46 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:17:46 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:17:50 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:17:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:18:02 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 234 ] in :
2014-09-23 14:18:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:18:04 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:18:04 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:18:06 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:18:06 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:18:20 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:18:20 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:18:33 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:18:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:18:36 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:18:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:18:49 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:18:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:18:50 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:18:50 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:18:51 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:18:51 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:18:52 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:18:52 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:19:36 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:19:36 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:19:36 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:19:36 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:19:41 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:19:41 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:20:05 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 70 ] in :
2014-09-23 14:20:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:20:05 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 161 ] in :
2014-09-23 14:20:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:20:09 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:20:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:20:10 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:20:10 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:20:11 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:20:11 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:20:40 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 105 ] in :
2014-09-23 14:20:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:20:40 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 69 ] in :
2014-09-23 14:20:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:20:41 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:20:41 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:21:10 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 156 ] in :
2014-09-23 14:21:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:21:11 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:21:11 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:21:13 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:21:13 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:21:40 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:21:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:21:40 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 227 ] in :
2014-09-23 14:21:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:21:43 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:21:43 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:22:11 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 175 ] in :
2014-09-23 14:22:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:22:15 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:22:15 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:22:16 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:22:16 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:22:34 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:22:34 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:22:45 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 105 ] in :
2014-09-23 14:22:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:22:48 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:22:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:23:02 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 175 ] in :
2014-09-23 14:23:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:23:04 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:23:04 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:23:05 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:23:05 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:23:33 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 185 ] in :
2014-09-23 14:23:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:23:33 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 123 ] in :
2014-09-23 14:23:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:23:34 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:23:34 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:24:03 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 171 ] in :
2014-09-23 14:24:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:24:23 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:24:23 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:24:26 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:24:26 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:24:53 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 106 ] in :
2014-09-23 14:24:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:24:53 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 105 ] in :
2014-09-23 14:24:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:24:54 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:24:54 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:25:23 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 161 ] in :
2014-09-23 14:25:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:25:25 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:25:25 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:25:25 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:25:25 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:25:54 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 123 ] in :
2014-09-23 14:25:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:25:54 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 117 ] in :
2014-09-23 14:25:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:25:55 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:25:55 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:26:24 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 125 ] in :
2014-09-23 14:26:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:26:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:26:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:26:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:26:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:26:51 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:26:51 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:27:01 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 175 ] in :
2014-09-23 14:27:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:27:18 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:27:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:27:21 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:27:21 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:27:22 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:27:22 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:27:32 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:27:32 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:27:50 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:27:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:27:50 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:27:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:28:00 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 156 ] in :
2014-09-23 14:28:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:28:03 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:28:03 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:28:04 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:28:04 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:28:22 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:28:22 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:28:31 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:28:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:28:35 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:28:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:28:51 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 156 ] in :
2014-09-23 14:28:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:28:53 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:28:53 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:28:54 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:28:54 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:29:22 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:29:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:29:22 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\UTF8.php [ 74 ] in :
2014-09-23 14:29:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:29:24 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:29:24 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:29:52 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:29:52 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:29:53 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:29:53 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:29:55 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:29:55 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:30:20 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:30:20 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:30:23 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 230 ] in :
2014-09-23 14:30:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:30:23 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:30:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:30:47 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 125 ] in :
2014-09-23 14:30:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:30:49 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:30:49 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:30:49 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:30:49 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:31:17 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 78 ] in :
2014-09-23 14:31:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:31:19 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 173 ] in :
2014-09-23 14:31:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:31:19 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:31:19 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:31:48 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 64 ] in :
2014-09-23 14:31:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:31:59 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:31:59 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:32:26 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 105 ] in :
2014-09-23 14:32:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:32:57 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH\classes\Controller\Ajax.php [ 53 ] in :
2014-09-23 14:32:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:33:51 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:33:51 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:33:53 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:33:53 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:34:20 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 105 ] in :
2014-09-23 14:34:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:34:20 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ SYSPATH\classes\Kohana\Debug.php [ 218 ] in :
2014-09-23 14:34:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:35:14 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH\classes\Controller\Ajax.php [ 25 ] in :
2014-09-23 14:35:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2014-09-23 14:35:15 --- CRITICAL: ErrorException [ 2 ]: fopen(course/jpy_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 96 ] in :
2014-09-23 14:35:15 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/jp...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(96): fopen('course/jpy_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getjpyval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:35:16 --- CRITICAL: ErrorException [ 2 ]: fopen(course/usd_val.js) [function.fopen]: failed to open stream: No such file or directory ~ APPPATH\classes\Controller\Ajax.php [ 43 ] in :
2014-09-23 14:35:16 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fopen(course/us...', 'Z:\home\avz125....', 43, Array)
#1 Z:\home\avz125.ru\www\application\classes\Controller\Ajax.php(43): fopen('course/usd_val....', 'w')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_getusdval()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#8 {main} in :
2014-09-23 14:59:14 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: root_page ~ APPPATH\views\template.php [ 120 ] in Z:\home\avz125.ru\www\application\views\template.php:120
2014-09-23 14:59:14 --- DEBUG: #0 Z:\home\avz125.ru\www\application\views\template.php(120): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 120, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(61): include('Z:\home\avz125....')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\avz125....', Array)
#3 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 Z:\home\avz125.ru\www\application\classes\Controller\Index.php(68): Kohana_Response->body(Object(View))
#6 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#9 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#12 {main} in Z:\home\avz125.ru\www\application\views\template.php:120
2014-09-23 15:02:38 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: search_result ~ APPPATH\views\main.php [ 36 ] in Z:\home\avz125.ru\www\application\views\main.php:36
2014-09-23 15:02:38 --- DEBUG: #0 Z:\home\avz125.ru\www\application\views\main.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 36, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(61): include('Z:\home\avz125....')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\avz125....', Array)
#3 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\avz125.ru\www\application\views\template.php(141): Kohana_View->__toString()
#5 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(61): include('Z:\home\avz125....')
#6 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\avz125....', Array)
#7 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\avz125.ru\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\avz125.ru\www\application\classes\Controller\Index.php(69): Kohana_Response->body(Object(View))
#10 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#13 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#16 {main} in Z:\home\avz125.ru\www\application\views\main.php:36
2014-09-23 15:27:16 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: search_car_request ~ APPPATH\views\main.php [ 55 ] in Z:\home\avz125.ru\www\application\views\main.php:55
2014-09-23 15:27:16 --- DEBUG: #0 Z:\home\avz125.ru\www\application\views\main.php(55): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 55, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(61): include('Z:\home\avz125....')
#2 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\avz125....', Array)
#3 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\avz125.ru\www\application\views\template.php(141): Kohana_View->__toString()
#5 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(61): include('Z:\home\avz125....')
#6 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\avz125....', Array)
#7 Z:\home\avz125.ru\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\avz125.ru\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\avz125.ru\www\application\classes\Controller\Index.php(101): Kohana_Response->body(Object(View))
#10 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#13 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#16 {main} in Z:\home\avz125.ru\www\application\views\main.php:55
2014-09-23 15:27:44 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: search_car ~ APPPATH\classes\Controller\Index.php [ 96 ] in Z:\home\avz125.ru\www\application\classes\Controller\Index.php:96
2014-09-23 15:27:44 --- DEBUG: #0 Z:\home\avz125.ru\www\application\classes\Controller\Index.php(96): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 96, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#7 {main} in Z:\home\avz125.ru\www\application\classes\Controller\Index.php:96
2014-09-23 16:12:17 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: search_result ~ APPPATH\classes\Controller\Index.php [ 117 ] in Z:\home\avz125.ru\www\application\classes\Controller\Index.php:117
2014-09-23 16:12:17 --- DEBUG: #0 Z:\home\avz125.ru\www\application\classes\Controller\Index.php(117): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\avz125....', 117, Array)
#1 Z:\home\avz125.ru\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 Z:\home\avz125.ru\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 Z:\home\avz125.ru\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 Z:\home\avz125.ru\www\index.php(118): Kohana_Request->execute()
#7 {main} in Z:\home\avz125.ru\www\application\classes\Controller\Index.php:117