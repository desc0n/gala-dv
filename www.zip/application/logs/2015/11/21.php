<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-11-21 15:19:54 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: categoryArr ~ APPPATH\views\category.php [ 7 ] in Z:\home\gala.lan\www\application\views\category.php:7
2015-11-21 15:19:54 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\gala.la...', 7, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\template.php(23): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Category.php(22): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Category->action_list()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Category))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\category.php:7