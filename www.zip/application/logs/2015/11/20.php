<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-11-20 13:59:34 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: get ~ APPPATH\views\add_notice.php [ 26 ] in Z:\home\gala.lan\www\application\views\add_notice.php:26
2015-11-20 13:59:34 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\add_notice.php(26): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\gala.la...', 26, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\admin_template.php(200): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(197): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\add_notice.php:26
2015-11-20 14:00:10 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Product' not found ~ SYSPATH\classes\Kohana\Model.php [ 26 ] in file:line
2015-11-20 14:00:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-11-20 14:07:28 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Product' not found ~ SYSPATH\classes\Kohana\Model.php [ 26 ] in file:line
2015-11-20 14:07:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-11-20 14:07:35 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Product' not found ~ SYSPATH\classes\Kohana\Model.php [ 26 ] in file:line
2015-11-20 14:07:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-11-20 14:13:49 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: product_id ~ APPPATH\views\admin_redact_notice.php [ 6 ] in Z:\home\gala.lan\www\application\views\admin_redact_notice.php:6
2015-11-20 14:13:49 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\admin_redact_notice.php(6): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\gala.la...', 6, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\admin_template.php(200): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(201): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\admin_redact_notice.php:6
2015-11-20 14:14:48 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Product' not found ~ SYSPATH\classes\Kohana\Model.php [ 26 ] in file:line
2015-11-20 14:14:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-11-20 14:15:09 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: productParams ~ APPPATH\views\admin_redact_notice.php [ 53 ] in Z:\home\gala.lan\www\application\views\admin_redact_notice.php:53
2015-11-20 14:15:09 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\admin_redact_notice.php(53): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\gala.la...', 53, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\admin_template.php(200): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(201): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\admin_redact_notice.php:53
2015-11-20 14:50:33 --- CRITICAL: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`galadvru_main`.`notice`, CONSTRAINT `notice_ibfk_2` FOREIGN KEY (`category`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE) [ update `notice`
        set `name` = 'ALIKO 1',
		`category` = '',
		`price` = '100000',
		`description` = '\n                    Impedit consectetur ipsam asperiores, animi aspernatur nemo, sapiente nisi magnam veritatis placeat temporibus quod quo. Consequuntur provident, omnis illum magni facere, molestias!\n                    Eaque esse perspiciatis dolores ipsum, animi ex optio reiciendis quos eligendi facere nisi impedit velit temporibus dolorum, laboriosam aliquid illo debitis sit.\n                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis velit non praesentium dignissimos commodi recusandae similique, harum possimus neque, modi esse dolore accusantium soluta sit eligendi tenetur reiciendis doloremque corporis!\n                    Dolores officia iste autem culpa sit quos maiores voluptate nemo possimus consequatur, odio minus esse exercitationem optio tempore eos iusto. Ipsum, neque.\n                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint maxime ipsa quo, quibusdam sapiente! Maxime pariatur praesentium alias nobis iste, illum nam fugiat modi illo deleniti earum, aut reprehenderit autem.\n                ',
		`short_description` = 'Impedit consectetur ipsam asperiores, animi aspernatur nemo, sapiente nisi magnam veritatis placeat temporibus quod quo. Consequuntur provident, omnis illum magni facere, molestias!',
		`status_id` = 1
		where `id` = '87' ] ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 194 ] in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php:251
2015-11-20 14:50:33 --- DEBUG: #0 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(3, 'update `notice`...', false, Array)
#1 Z:\home\gala.lan\www\application\classes\Model\Notice.php(83): Kohana_Database_Query->execute()
#2 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(141): Model_Notice->setNotice(Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#6 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php:251
2015-11-20 15:14:55 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: noticeParams ~ APPPATH\views\item.php [ 30 ] in Z:\home\gala.lan\www\application\views\item.php:30
2015-11-20 15:14:55 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\item.php(30): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\gala.la...', 30, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\template.php(23): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Item.php(20): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Item->action_show()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Item))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\item.php:30
2015-11-20 15:25:02 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\classes\Model\Admin.php [ 73 ] in Z:\home\gala.lan\www\application\classes\Model\Admin.php:73
2015-11-20 15:25:02 --- DEBUG: #0 Z:\home\gala.lan\www\application\classes\Model\Admin.php(73): Kohana_Core::error_handler(2, 'Invalid argumen...', 'Z:\home\gala.la...', 73, Array)
#1 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(129): Model_Admin->loadNoticeImg(Array, '1')
#2 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#5 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#8 {main} in Z:\home\gala.lan\www\application\classes\Model\Admin.php:73
2015-11-20 15:42:35 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\classes\Model\Admin.php [ 74 ] in Z:\home\gala.lan\www\application\classes\Model\Admin.php:74
2015-11-20 15:42:35 --- DEBUG: #0 Z:\home\gala.lan\www\application\classes\Model\Admin.php(74): Kohana_Core::error_handler(2, 'Invalid argumen...', 'Z:\home\gala.la...', 74, Array)
#1 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(129): Model_Admin->loadNoticeImg(Array, '1')
#2 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#5 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#8 {main} in Z:\home\gala.lan\www\application\classes\Model\Admin.php:74
2015-11-20 15:49:21 --- CRITICAL: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\views\item.php [ 11 ] in Z:\home\gala.lan\www\application\views\item.php:11
2015-11-20 15:49:21 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\item.php(11): Kohana_Core::error_handler(2048, 'Only variables ...', 'Z:\home\gala.la...', 11, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\template.php(23): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Item.php(21): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Item->action_show()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Item))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\item.php:11
2015-11-20 15:50:02 --- CRITICAL: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\views\item.php [ 12 ] in Z:\home\gala.lan\www\application\views\item.php:12
2015-11-20 15:50:02 --- DEBUG: #0 Z:\home\gala.lan\www\application\views\item.php(12): Kohana_Core::error_handler(2048, 'Only variables ...', 'Z:\home\gala.la...', 12, Array)
#1 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#2 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#3 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\gala.lan\www\application\views\template.php(23): Kohana_View->__toString()
#5 Z:\home\gala.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\gala.la...')
#6 Z:\home\gala.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\gala.la...', Array)
#7 Z:\home\gala.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\gala.lan\www\application\classes\Controller\Item.php(21): Kohana_Response->body(Object(View))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Item->action_show()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Item))
#13 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\gala.lan\www\application\views\item.php:12