<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-11-29 15:25:02 --- CRITICAL: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`galadvru_main`.`notice_sale_img`, CONSTRAINT `notice_sale_img_ibfk_1` FOREIGN KEY (`notice_id`) REFERENCES `notice_sale` (`id`) ON UPDATE CASCADE) [ insert into `notice_sale_img` (`notice_id`) values ('big') ] ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 194 ] in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php:251
2015-11-29 15:25:02 --- DEBUG: #0 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(2, 'insert into `no...', false, Array)
#1 Z:\home\gala.lan\www\application\classes\Model\Admin.php(145): Kohana_Database_Query->execute()
#2 Z:\home\gala.lan\www\application\classes\Controller\Admin.php(195): Model_Admin->loadNoticeSaleImg(Array, 'big')
#3 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Admin->action_control_panel()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin))
#6 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php:251