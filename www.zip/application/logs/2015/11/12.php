<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-11-12 13:46:02 --- CRITICAL: Database_Exception [ 2 ]: mysql_connect(): Access denied for user 'galadvru_root'@'localhost' (using password: YES) ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 67 ] in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php:171
2015-11-12 13:46:02 --- DEBUG: #0 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php(171): Kohana_Database_MySQL->connect()
#1 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(3, 'SET time_zone =...', false, Array)
#2 Z:\home\gala.lan\www\application\classes\Model\Admin.php(14): Kohana_Database_Query->execute()
#3 Z:\home\gala.lan\www\system\classes\Kohana\Model.php(26): Model_Admin->__construct()
#4 Z:\home\gala.lan\www\application\classes\Controller\Index.php(9): Kohana_Model::factory('Admin')
#5 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#8 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#11 {main} in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php:171
2015-11-12 13:47:07 --- CRITICAL: Database_Exception [ 1049 ]: Unknown database 'galadvru_main' ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 108 ] in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php:75
2015-11-12 13:47:07 --- DEBUG: #0 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php(75): Kohana_Database_MySQL->_select_db('galadvru_main')
#1 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php(171): Kohana_Database_MySQL->connect()
#2 Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(3, 'SET time_zone =...', false, Array)
#3 Z:\home\gala.lan\www\application\classes\Model\Admin.php(14): Kohana_Database_Query->execute()
#4 Z:\home\gala.lan\www\system\classes\Kohana\Model.php(26): Model_Admin->__construct()
#5 Z:\home\gala.lan\www\application\classes\Controller\Index.php(9): Kohana_Model::factory('Admin')
#6 Z:\home\gala.lan\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#9 Z:\home\gala.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 Z:\home\gala.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 Z:\home\gala.lan\www\index.php(119): Kohana_Request->execute()
#12 {main} in Z:\home\gala.lan\www\modules\database\classes\Kohana\Database\MySQL.php:75