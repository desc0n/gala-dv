<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-05-26 12:56:41 --- CRITICAL: Database_Exception [ 2 ]: mysql_connect():  ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 67 ] in Z:\home\morya.lan\www\modules\database\classes\Kohana\Database\MySQL.php:171
2015-05-26 12:56:41 --- DEBUG: #0 Z:\home\morya.lan\www\modules\database\classes\Kohana\Database\MySQL.php(171): Kohana_Database_MySQL->connect()
#1 Z:\home\morya.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(3, 'SET time_zone =...', false, Array)
#2 Z:\home\morya.lan\www\application\classes\Model\Admin.php(14): Kohana_Database_Query->execute()
#3 Z:\home\morya.lan\www\system\classes\Kohana\Model.php(26): Model_Admin->__construct()
#4 Z:\home\morya.lan\www\application\classes\Controller\Category.php(13): Kohana_Model::factory('Admin')
#5 Z:\home\morya.lan\www\system\classes\Kohana\Controller.php(84): Controller_Category->action_list()
#6 [internal function]: Kohana_Controller->execute()
#7 Z:\home\morya.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Category))
#8 Z:\home\morya.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 Z:\home\morya.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 Z:\home\morya.lan\www\index.php(119): Kohana_Request->execute()
#11 {main} in Z:\home\morya.lan\www\modules\database\classes\Kohana\Database\MySQL.php:171