<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-04-26 07:34:25 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Word::getWord() ~ APPPATH\classes\Controller\Admin.php [ 110 ] in file:line
2015-04-26 07:34:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-04-26 07:35:35 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) ~ APPPATH\classes\Controller\Admin.php [ 112 ] in file:line
2015-04-26 07:35:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line