<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-04-15 17:17:38 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Model\Cart.php [ 232 ] in file:line
2015-04-15 17:17:38 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Array to string...', 'Z:\home\teleant...', 232, Array)
#1 Z:\home\teleantenna.lan\www\application\classes\Model\Cart.php(232): array_unique(Array)
#2 Z:\home\teleantenna.lan\www\application\classes\Controller\Ajax.php(120): Model_Cart->getMainAssort(Array)
#3 Z:\home\teleantenna.lan\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_get_main_assort()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#6 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\teleantenna.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in file:line
2015-04-15 17:17:39 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Model\Cart.php [ 232 ] in file:line
2015-04-15 17:17:39 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Array to string...', 'Z:\home\teleant...', 232, Array)
#1 Z:\home\teleantenna.lan\www\application\classes\Model\Cart.php(232): array_unique(Array)
#2 Z:\home\teleantenna.lan\www\application\classes\Controller\Ajax.php(120): Model_Cart->getMainAssort(Array)
#3 Z:\home\teleantenna.lan\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_get_main_assort()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#6 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\teleantenna.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in file:line
2015-04-15 17:17:41 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Model\Cart.php [ 232 ] in file:line
2015-04-15 17:17:41 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Array to string...', 'Z:\home\teleant...', 232, Array)
#1 Z:\home\teleantenna.lan\www\application\classes\Model\Cart.php(232): array_unique(Array)
#2 Z:\home\teleantenna.lan\www\application\classes\Controller\Ajax.php(120): Model_Cart->getMainAssort(Array)
#3 Z:\home\teleantenna.lan\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_get_main_assort()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#6 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\teleantenna.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in file:line
2015-04-15 17:17:43 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Model\Cart.php [ 232 ] in file:line
2015-04-15 17:17:43 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Array to string...', 'Z:\home\teleant...', 232, Array)
#1 Z:\home\teleantenna.lan\www\application\classes\Model\Cart.php(232): array_unique(Array)
#2 Z:\home\teleantenna.lan\www\application\classes\Controller\Ajax.php(120): Model_Cart->getMainAssort(Array)
#3 Z:\home\teleantenna.lan\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_get_main_assort()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#6 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\teleantenna.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\teleantenna.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in file:line