<div class="regform">
	<div class="alert alert-danger" style="background: #f0f0f0;color: #FF0000;">
		<strong><?=$zag?></strong> <?=$mess?>
	</div>
</div>